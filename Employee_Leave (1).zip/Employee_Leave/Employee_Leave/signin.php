<!--link rel="shortcut icon" type="image/png" href="favicon.png"/-->
<?php
session_start();
if(isset($_SESSION['adminuser']))
	{
	header('location:home.php');
	}
		if(isset($_GET['err']))
		{
			//echo "<div class = 'error'><b><u>".htmlspecialchars($_GET['err'])."</u></b></div><br/>";
			$message1 = htmlspecialchars($_GET['err']);
			echo "<script type='text/javascript'>alert('$message1');</script>";
			header( "refresh:1;url=signin.php" );
		}
?>

<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" type="text/css" href="signin.css">
<script type = "text/javascript">
function valid()
{
	var user = document.login.uname.value;
	var user = user.trim();
	var pass = document.login.pass.value;
	if (user == '')
		{
			alert("Please Enter Username !");
			return false;
		}
	else if (pass == '')
		{
			alert("Please Enter Password !");
			return false;
		}
	else
		{
			return true;
		}
}
</script>

</head>

<html>
<head>
<title>::Leave Management::</title>
<!--link rel="stylesheet" type="text/css" href="style.css"-->
<link rel="stylesheet" type="text/css" href="signin.css">
<script type = "text/javascript">
function valid()
{
	var user = document.login.uname.value;
	var user = user.trim();
	var pass = document.login.pass.value;
	if (user == '')
		{
			alert("Please Enter Username !");
			return false;
		}
	else if (pass == '')
		{
			alert("Please Enter Password !");
			return false;
		}
	else
		{
			return true;
		}
}
</script>

</head>

<body>
<?php include 'navi3.php';?>
<!--div class="card col-sm-4 col-lg-4 justify-content-center"-->
<form class="form-signin" name='login' action='validator.php' method = 'post' onsubmit = 'return valid()'>
  <!--img class="mb-4 rounded mx-auto d-block" src="default-image.png" alt="" width="72" height="72"-->
  <h1 class="h2 mb-2 font-weight-normal" style='text-shadow: 0px 0px 2px #000000;'>Please login...</h1>
  <br>
  <!--label for="inputEmail" class="sr-only" >Email address</label-->
  <input type="text" id="inputEmail" class="form-control" placeholder="Username" name='uname' required autofocus>
  <!--label for="inputPassword" class="sr-only">Password</label-->
  <br>
  <input type="password" id="inputPassword" class="form-control" placeholder="Password" name='pass' required>

  <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>

  <h4><a class="mt-5 mb-3 text-muted" href = 'passrecovery.php' style='text-shadow: 0px 0px 2px #000000;'>Forgot Your Password?</a></h4>
</form>
</div>


</body>
</html>

