<html>
<head>
<title>::Leave Management::</title>
<!--link rel="stylesheet" href="style.css"-->
</head>
<body>
<?php
include 'navi2.php';
echo "<div class = 'heading'>";
echo "<center>";
echo "<h4> Page Under Construction ! </h4>";
echo "</center>";
echo "</div>";
?>