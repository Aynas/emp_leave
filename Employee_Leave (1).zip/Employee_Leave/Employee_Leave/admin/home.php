<link rel="shortcut icon" type="image/png" href="favicon.png"/>
<?php
session_start();
include 'adminnavi3.php';
if(isset($_SESSION['adminuser']))
		{
		if(isset($_GET['msg']))
			{
				$message1 = htmlspecialchars($_GET['msg']);
				echo "<script type='text/javascript'>alert('$message1');</script>";
				header( "refresh:1;url=home.php" );			}
		}
else
	{
		header('location:../signin.php?err='.urlencode('Please Login first to access this page'));
	}

?>

<html>
<head>
<title>::Leave Management::</title>
</head>
<body>
<h1 style="text-align:center;color:#009688;font-size:60px;text-shadow: 0px 0px 2px #000000;">Welcome!</h1>
</body>
</html>
