<?php
session_start();
include 'adminnavi3.php';
if(isset($_SESSION['adminuser']))
		{
      if(isset($_GET['err']))
      {
        //echo "<div class = 'error'><b><u>".htmlspecialchars($_GET['err'])."</u></b></div><br/>";
        $message1 = htmlspecialchars($_GET['err']);
        echo "<script type='text/javascript'>alert('$message1');</script>";
        header( "refresh:1;url=register.php" );
      }
    }
else
	{
		header('location:../signin.php?err='.urlencode('Please Login first to access this page'));
	}

?>

<html>
<head>
<title>::Leave Management::</title>
<style>
body {
  overflow-y: scroll; /* Add the ability to scroll */
}

/* Hide scrollbar for Chrome, Safari and Opera */
body::-webkit-scrollbar {
    display: none;
}

/* Hide scrollbar for IE and Edge */
body {
    -ms-overflow-style: none;
}
</style>
<script type="text/javascript">
function disableField(val) {
    console.log(val);
    var selecttype = document.getElementById("selecttype");
    var desiginput = document.getElementById("desiginput");
    var dojinput = document.getElementById("dojinput");
    var selectdept = document.getElementById("selectdept");
  if( val == "Director" || val == "HOD"  ) {
    selecttype.disabled = true;
    desiginput.disabled = true;
  }else{
    selecttype.disabled = false;
    desiginput.disabled = false;    
  }
  if(val =="Director"){
    dojinput.disabled = true;
    selectdept.disabled = true;
  }
  else{
    dojinput.disabled = false;
    selectdept.disabled = false;
  }

}
</script>
</head>
<body style='padding-bottom:80px;'>
<div class='container-fluid'>
<div class="card rounded-0 col align-self-center" style="padding-left:20px;padding-right:20px;padding-top:10px;padding-bottom:10px; background-color:white; " >
<div class="card-header">
    <h3 class="mb-0">Register New Employee</h3>
</div>
<hr/>
<div class="card-body">
  <!-- <div class="error"></div> -->
  <!-- <?php
    if(isset($_POST['sendotp'])){

    
    // require('textlocal.class.php');
    // require('credentials.php');

    // $textlocal = new Textlocal(false,false, API_KEY);

    // $numbers = $_POST['mobinput'];
    // $sender = 'TXTLCL';
    // $otp= mt_rand(10000,99999);
    // $message = 'Your Otp is '.$otp;

    // try {
    //     $result = $textlocal->sendSms($numbers, $message, $sender);
    //     print_r($result);
    //     setcookie('otp',$otp);
    //     echo "OTP successfully send.";
    // } catch (Exception $e) {
    //     die('Error: ' . $e->getMessage());
    // }


    // Account details
	$apiKey = urlencode('8MStLia+r0-3DV3lBUrYAVyXwKaEcEJMETYLJwdY8');
     $otp= mt_rand(10000,99999);
	
	// Message details
	// $numbers = array(918123456789, 918987654321);
	$sender = urlencode('TXTLCL');
	$message = rawurlencode($otp);
 
	$numbers =$_POST['mobinput'];
 
	// Prepare data for POST request
	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// Send the POST request with cURL
	$ch = curl_init('https://api.textlocal.in/send/');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	
	// Process your response here
	echo $response;
  }
  if(isset($_POST['verifyotp'])){
    $otp=$_POST['otp'];
    if($_COOKIE['otp'] == $otp){
      echo "Congratulation, Your mobile is verified";
    } else {
      echo "Please enter correct otp.";
    }
  }
?> -->
  
<form class="form-horizontal" action='save.php' method = 'post' enctype="multipart/form-data">
<fieldset>


<!-- Text input-->
<div class='row '>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="nameinput">Name :</label>  
  <div class="col-md-6">
  <input id="nameinput" name="nameinput" type="text" placeholder="placeholder" class="form-control input-md" required> 
  </div>
</div>
</div>

<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="mobinput">Mobile No :</label>  
  <div class="col-md-6">
  <input id="mobinput" name="mobinput" type="tel" placeholder="placeholder" class="form-control input-md" pattern="[0-9]{10}" maxlength="12" required><br>
  <input type="button" class="btnSubmit" value="Send OTP" id="sendotp">
  </div>
</div>
</div>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label">OTP :</label>  
  <div class="col-md-6">
  <input id="otp" name="otp" type="text" placeholder="Enter OTP" class="form-control input-md" maxlength="5" required><br>
  <input type="button" class="btnSubmit" value="Verify OTP" id="verifyotp">
  </div>
</div>
</div>
</div>

<!-- Text input-->
<div class='row'>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="usrnminput">Username :</label>  
  <div class="col-md-6">
  <input id="usrnminput" name="usrnminput" type="text" placeholder="placeholder" class="form-control input-md" required> 
  </div>
</div>
</div>

<!-- Text input-->
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="passinput">Password :</label>  
  <div class="col-md-6">
  <input id="passinput" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" title="UpperCase, LowerCase, Number/SpecialChar and min 8 Chars" name="passinput" type="password" placeholder="placeholder" class="form-control input-md" required> 
  </div>
</div>
</div>
</div>

<!-- Text input-->
<div class='row'>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="emailinput">Email Id :</label>  
  <div class="col-md-6">
  <input id="emailinput" name="emailinput" type="email" placeholder="placeholder" class="form-control input-md" required>  
  </div>
</div>
</div>

<!-- Select Basic -->
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="selectdept">Department :</label>
  <div class="col-md-6">
    <select id="selectdept" name="selectdept" class="form-control" required>
      <option value="IT">IT</option>
      <option value="CS">CS</option>
      <option value="EXTC">EXTC</option>  
    </select>
  </div>
</div>
</div>
</div>
<!-- Text input-->
<div class='row'>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="dojinput">Date Of Joining :</label>  
  <div class="col-md-6">
  <input id="dojinput" name="dojinput" type="date" placeholder="placeholder" class="form-control input-md" required> 
  </div>
</div>
</div>

<!-- Text input-->
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="desiginput">Designation :</label>  
  <div class="col-md-6">
  <input id="desiginput" name="desiginput" type="text" placeholder="placeholder" class="form-control input-md" required>
  </div>
</div>
</div>
</div>

<!-- Select Basic -->
<div class='row'>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="selectempis">Employee Category :</label>
  <div class="col-md-6">
    <select id="selectempis" name="selectempis" class="form-control" onclick="disableField(this.value)" required>
      <option value="Director">Director</option>
      <option value="HOD">HOD</option>
      <option value="Teaching">Teaching</option>
      <option value="Non-Teaching">Non-Teaching</option>
    </select>
  </div>
</div>
</div>

<!-- Select Basic -->
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="selecttype">Employee Type :</label>
  <div class="col-md-6">
    <select id="selecttype" name="selecttype" class="form-control" required>
      <option value="Temporary">Temporary</option>
      <option value="Permanent">Permanent</option>
    </select>
  </div>
</div>
</div>
</div>

<!-- Text input-->
<div class='row'>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="dobinput">Date Of Birth :</label>  
  <div class="col-md-6">
    <input id="dobinput" name="dobinput" type="date" placeholder="placeholder" class="form-control input-md" required>
  </div>
</div>
</div>
<!--Profile Picture-->
<div class='row'>
<div class="col-md-4">
<div class="form-group">
  <label class="col-md-4 control-label" for="profilepicture">Profile Picture:</label> 
  <input type="file" name="image" id="image" > <br> 
 
</div>
</div>


</div>
<!-- Button -->
<div class="col-lg-2"></div>
<div class='row'>
<div class="col-xs-6">
<div class="form-group">
  <div class="col-md-6">
    <button id="singlebutton" name="submit" class="btn btn-primary btn-block">Submit</button>
  </div>
</div>
</div>
</div>

</fieldset>
</form>
</div>
</div>
</div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
<script src="verification.js"></script>
<script>
  $(document).ready(function(){
    $('#sendotp').click(function(){
      console.log();
      var mobile=$("#mobinput").val();
      console.log(mobile);
      $.ajax({
                url: "sendotp.php",
                type: "POST",
                data:{ mobile: mobile},
               
                success: function(result){
                   console.log(result);
                   if(result=='sent'){
                     alert("OTP Successfully sent to your mobile number");
                   }
                   
                }
            });

    })

    // verify otp
    $('#verifyotp').click(function(){
      console.log();
      var otp=$("#otp").val();
      // console.log(mobile);
      $.ajax({
                url: "verifyotp.php",
                type: "POST",
                data:{ otp: otp},
               
                success: function(result){
                   console.log(result);
                   if(result=='Congratulation'){
                     alert("OTP Verified Successfully ");
                   }
                   
                }
            });

    })
  })
</script>

</html>