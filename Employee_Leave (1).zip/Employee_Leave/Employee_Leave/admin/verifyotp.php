<?php

 if(isset($_POST['otp'])){
    $otp=$_POST['otp'];
    if($_COOKIE['otp'] == $otp){
      echo "Congratulation";
    } else {
      echo "Please enter correct otp.";
    }
  }
?>