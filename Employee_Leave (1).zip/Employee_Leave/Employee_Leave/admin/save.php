<?php
session_start();
if(isset($_SESSION['adminuser']))
{ 
  //include 'adminnavi3.php';	
  include 'connect.php';
  //$user = $_SESSION['adminuser'];
    if(isset($_POST['submit']))
    { // Fetching variables of the form which travels in URL
          
       
    
           
            
              
      
      
             
              
         
              
         
              // Check if $uploadOk is set to 0 by an error
             
                  
                  // if everything is ok, try to upload file
                
             
                  if (move_uploaded_file($_FILES["image"]["tmp_name"], $img_file)) {
         
                    $stmt = $conn->prepare("INSERT INTO library (name, thumbnail,pdf) VALUES (?,?,?)");
                    $result = $stmt->execute([$book_title,$img_name,$pdf_name]);
                    if($result){
                       $notify=1;
                    } 
                  }else{
                    $notify='error';
                  }
                  
            
         


                  $img_name      = date('d-m-Y-H-i-s').'-'.$_FILES["image"]["name"];
           
                  //for image
                  $img_dir = "../image/";
                  $img_file = $img_dir .date('d-m-Y-H-i-s').'-'. basename($_FILES["image"]["name"]);
          
        $Name = $_POST['nameinput'];
        $Username = $_POST['usrnminput'];
        $Pass = $_POST['passinput'];
        $Email = $_POST['emailinput'];
        $Dept = $_POST['selectdept'];
        $DOJ = $_POST['dojinput'];
        $Desig = $_POST['desiginput'];
        $Category = $_POST['selectempis'];
        $Type = $_POST['selecttype'];
        $DOB = $_POST['dobinput'];
        $Mobile = $_POST['mobinput'];
        $flag = 0;
        if(preg_match("/emp/",$Username))
            {
                $sql="SELECT * FROM employees WHERE  UserName = '".$Username."'";
            }
        elseif(preg_match("/hod/",$Username))
            {
                $sql="SELECT * FROM hod WHERE  UserName = '".$Username."'";
            }
        elseif(preg_match("/director/",$Username))
            {
                $sql="SELECT * FROM director WHERE  UserName = '".$Username."'";
            }

        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            header('location:register.php?err='.urlencode('Username already exists!'));
            $flag = 1;
            exit();
        }

        if($flag==0)
        {
            if(preg_match("/emp/",$Username))
            {
               if($Category=='Teaching')
               {
                   if($Type=='Permanent')
                   {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth, image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,10,8,7,0,0,0,30,40, '$DOJ', '$Desig', '$Category', '$Type', '$DOB','$img_name')";
                   }
                   if($Type=='Temporary')
                   {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth,image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,0,8,0,0,0,0,7,7, '$DOJ', '$Desig', '$Category', '$Type', '$DOB','$img_name')";
                   }
               }
               elseif($Category=='Non-Teaching')
               {
                    if($Type=='Permanent')
                    {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth,image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,10,8,7,0,0,0,0,0, '$DOJ', '$Desig', '$Category', '$Type', '$DOB','$img_name')";
                    }
                    if($Type=='Temporary')
                    {
                        $sql = "INSERT INTO employees(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, Designation, Faculty, EmpType, DateOfBirth,image) values 
                        ('$Username','$Pass','$Name','$Email', '$Mobile', '$Dept', 0,0,0,0,0,0,0,0,0, '$DOJ', '$Desig', '$Category', '$Type', '$DOB','$img_name')";
                    }
               }
            }
        elseif(preg_match("/hod/",$Username))
            {
                $sql = "INSERT INTO hod(UserName, EmpPass, EmpName, EmpEmail, Mobile, Dept, EarnLeave, SickLeave, CasualLeave, SpecialLeave, OutdoorLeave, LeaveWithoutPay, CompensatoryLeave, SummerVacation, WinterVacation, DateOfJoin, DateOfBirth,image) values ('$Username', '$Pass','$Name','$Email','$Mobile','$Dept',0,10,8,7,0,0,0,30,40,$DOJ,$DOB,'$img_name')";
            }
        elseif(preg_match("/director/",$Username))
            {
                $sql="INSERT INTO director(UserName, EmpPass, EmpName, EmpEmail, DateOfBirth, Mobile,image) values ('$Username','$Pass','$Name','$Email','$DOB', '$Mobile','$img_name')";
            }
        if(move_uploaded_file($_FILES["image"]["tmp_name"], $img_file)){
            if ($conn->query($sql) === TRUE) {
                
                $message1 = "User Registered Successfully!";
                header('location:register.php?err='.urlencode($message1));
                exit();
                
                //$msg="Leave Application Credentials are Username: $Username and Password: $Pass";
                //$num=$Mobile;
            
                //echo "<script type='text/javascript'>alert('$message1');</script>";
                //header('refresh:1;url=../sendmsg.php?msg='.urlencode($msg).'&num='.urlencode($num));
                
            }
            else{
                header('location:register.php?err='.urlencode('Error while registering!'));
                exit();
                }
            }
        }else{
            header('location:register.php?err='.urlencode('Error while uploading Image!'));
            exit();
        }
    }
    header('location:register.php');
    exit();
}
else
{
    header('location:index.php?err='.urlencode('Please Login First For Accessing This Page !'));
    exit();
}
//mysql_close($connection); // Closing Connection with Server
?>

