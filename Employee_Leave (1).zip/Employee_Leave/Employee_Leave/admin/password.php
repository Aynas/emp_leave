<?php
session_start();
//include 'clientnavi3.php';
include 'connect.php';
if(isset($_SESSION['adminuser']))
{
	$oldpass = $_POST['oldpass'];
	$newpass = $_POST['newpass'];
	$cnfnewpass = $_POST['cnfnewpass']; 
	$uname = $_SESSION['adminuser'];
	if($newpass == $cnfnewpass)
		{
        $sql = "SELECT * FROM admins where UserName='".$uname."'";
        $result = $conn->query($sql);
        if($result->num_rows>0)
        {
            while($row = $result->fetch_assoc())
		    {
            if($oldpass == $row["EmpPass"])
			{
            $sql2 = "UPDATE admins SET EmpPass='".$newpass."' WHERE UserName='".$uname."'";
			if($conn->query($sql2) === TRUE)
			{
			    header("location:home.php?err=".urlencode('Password Succesfully Changed !'));
            }
            else{
                header("location:changepass.php?err=".urlencode('Error !'));
            }
        }
			else
			{
				header("location:changepass.php?err=".urlencode('Incorrect Old Password !'));
			}
        }}
        else{
            $msg="No user found!";
            echo "<script type='text/javascript'>alert($msg);</script>";
        }
    }
    else{
        $msg="New Password and Confirm New Password doesn't match!";
        echo "<script type='text/javascript'>alert($msg);</script>";
    }
}
    else{
        header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
        exit();
    }

  ?>      