<?php
define("API_KEY", '/8MStLia+r0-3DV3lBUrYAVyXwKaEcEJMETYLJwdY8');
?>