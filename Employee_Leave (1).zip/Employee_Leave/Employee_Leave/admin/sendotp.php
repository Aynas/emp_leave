<?php
//   //Your authentication key
// $authKey = "342098A2GMjXSd75f651280P1";
// //Sender ID,While using route4 sender id should be 6 characters long.
// $senderId = "LeaveMS1";

// //Multiple mobiles numbers separated by comma
// $mobileNumber = array($_POST['mobile']);



// //Your message to send, Add URL encoding here.
// $message = "Your Verification OTP code is ##OTP##";


// //Prepare you post parameters
// $postData = array(
//     'authkey' => $authKey,
//     'mobiles' => $mobileNumber,
//     'message' => $message,
//     'sender' => $senderId,
    
// );

// //API URL
// $url="https://api.msg91.com/api/v5/otp";

// $curl = curl_init($url);

// curl_setopt_array($curl, array(
//   // CURLOPT_URL => "https://api.msg91.com/api/v5/otp?extra_param=%7B%22Param1%22%3A%22Value1%22%2C%20%22Param2%22%3A%22Value2%22%2C%20%22Param3%22%3A%20%22Value3%22%7D&unicode=&authkey=Authentication%20Key&template_id=Template%20ID&mobile=Mobile%20Number%20with%20Country%20Code&invisible=1&otp=OTP%20to%20send%20and%20verify.%20If%20not%20sent%2C%20OTP%20will%20be%20generated.&userip=IPV4%20User%20IP&email=Email%20ID&otp_length=&otp_expiry=",
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => "",
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 30,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => "GET",
//   CURLOPT_SSL_VERIFYHOST => 0,
//   CURLOPT_SSL_VERIFYPEER => 0,
//   CURLOPT_HTTPHEADER => array(
//     "content-type: application/json"
//   ),
// ));

// $response = curl_exec($curl);
// $err = curl_error($curl);

// curl_close($curl);

// if ($err) {
//   echo "cURL Error #:" . $err;
// } else {
//   echo $response;
// }
    
    require('textlocal.class.php');
    require('credentials.php');

    $textlocal = new Textlocal(false,false, API_KEY);

    $numbers =array($_POST['mobile']) ;
    $sender = 'TXTLCL';
    $otp= mt_rand(10000,99999);
    $message = 'Your Otp is '.$otp;

    try {
        $result = $textlocal->sendSms($numbers, $message, $sender);
       
        setcookie('otp',$otp);
       echo "sent";
    } catch (Exception $e) {
        die('Error: ' . $e->getMessage());
    }


    // // Account details
	// $apiKey = urlencode('/8MStLia+r0-3DV3lBUrYAVyXwKaEcEJMETYLJwdY8');
    //  $otp= mt_rand(10000,99999);
	
	// // Message details
	// // $numbers = array(918123456789, 918987654321);
	// $sender = urlencode('TXTLCL');
	// $message = rawurlencode($otp);
 
	// $numbers =$_POST['mobile'];
 
	// // Prepare data for POST request
	// $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
	// // Send the POST request with cURL
	// $ch = curl_init('https://api.textlocal.in/send/');
	// curl_setopt($ch, CURLOPT_POST, true);
	// curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	// $response = curl_exec($ch);
	// curl_close($ch);
	
	// // Process your response here
	// echo $response;
    
  
?>