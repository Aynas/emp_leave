<!DOCTYPE html>
<html>
<head>
<!--link href='https://fonts.googleapis.com/css?family=Lato:400,300,400italic,700,900' rel='stylesheet' type='text/css'-->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!-- Bootstrap css -->
<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<link href="../assets/css/bootstrap.techie.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-inverse" role="navigation">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex3-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                <a class="navbar-brand" href="home.php">Home</a>
              </div>

              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse navbar-ex3-collapse">
                <ul class="nav navbar-nav">
                <li><a href="applyleave.php">Request Leave</a></li>
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Me <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      <li><a href="my_leaves.php">All Leave Requests</a></li>
                      <li><a href="changepass.php">Change Password</a></li>
                      <li><a href="logout.php">Logout</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
              <!-- /.navbar-collapse -->
            </nav>
          
            <nav class="navbar navbar-inverse navbar-fixed-bottom text-center">
            <h4 style="color:white;">&copy; Leave Management System</h4>
            </nav>

<!-- Main Scripts-->
<script src="../assets/js/jquery.js"></script>
  <script src="../assets/js/bootstrap.min.js"></script>

  <!-- Bootstrap 3 has typeahead optionally -->
  <script src="../assets/js/typeahead.min.js"></script>

</body>

</html>