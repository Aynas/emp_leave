<?php
session_start();
//include 'clientnavi3.php';
include 'connect.php';
if(isset($_SESSION['empuser']))
{
	$oldpass = $_POST['oldpass'];
	$newpass = $_POST['newpass'];
	$cnfnewpass = $_POST['cnfnewpass']; 
	$uname = $_SESSION['empuser'];
	if($newpass == $cnfnewpass)
		{
        $sql = "SELECT * FROM employees where UserName='".$uname."'";
        $result = $conn->query($sql);
        if($result->num_rows>0)
        {
            while($row = $result->fetch_assoc())
		    {
            if($oldpass == $row["EmpPass"])
			{
            $sql2 = "UPDATE employees SET EmpPass='".$newpass."' WHERE UserName='".$uname."'";
			if($conn->query($sql2) === TRUE)
			{
                header("location:home.php?err=".urlencode('Password Succesfully Changed !'));
                exit();
            }
            else{
                header("location:changepass.php?err=".urlencode('Error !'));
                exit();
            }
        }
			else
			{
                header("location:changepass.php?err=".urlencode('Incorrect Old Password !'));
                exit();
			}
        }}
        else{
            header("location:changepass.php?err=".urlencode("No user found!"));
            exit();
        }
    }
    else{
        header("location:changepass.php?err=".urlencode("New Password and Confirm New Password doesn't match!"));
        exit();
    }
}
    else{
        header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
        exit();
    }

  ?>      