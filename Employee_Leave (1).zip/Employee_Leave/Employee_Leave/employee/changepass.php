<?php
session_start();
?>
<html>
<head>
<title>::Leave Management::</title>
</head>
<link rel = "stylesheet" type = "text/css" href = "style.css">
<body>

	<?php
	//echo "<h1>Leave Management System</h1>";
	include 'clientnavi3.php';
	if(isset($_SESSION['empuser']))
	{
		//echo "<h2>Change Password</h2>";
		if(isset($_GET['err']))
		{
            $message1 = htmlspecialchars($_GET['err']);
			echo "<script type='text/javascript'>alert('$message1');</script>";
			header( "refresh:1;url=changepass.php" );
        }
    }
    else
{
    header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
    exit();
}
	?>
<div class="container" style="background-color:white; padding-top:20px; width:500px">
<form class="form-signin" action = "password.php" method = "post">
<div class="form-group row">

    <label class="col-sm-4 col-form-label" for="textinput1">Old Password :</label> 
    <div class="col-sm-10"> 
		 <input type = "password" name = "oldpass" class="form-control" id="textinput1"> 
	</div>
    </div>
    <div class="form-group row">

    <label class="col-sm-4 col-form-label" for="textinput2">New Password :</label> 
    <div class="col-sm-10"> 	
		<input type = "password" name = "newpass" class="form-control" id="textinput1"> 
        </div>
    </div>

        <div class="form-group row">

	<label class="col-sm-4 col-form-label" for="textinput3">Confirm New Password :</label> 
    <div class="col-sm-10">
		 <input type = "password" name = "cnfnewpass" class="form-control" id="textinput1"> 
         </div>
    </div>

		<button class="btn btn-lg btn-primary" type="submit">Submit</button>
</form>
</center>
</div>
</body>
</html>