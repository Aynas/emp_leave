<?php
session_start();
if(isset($_SESSION['empuser']))
{ 
 	
  include 'connect.php';
  $user = $_SESSION['empuser'];
  $sql="SELECT * FROM employees WHERE  UserName = '".$user."'";
  $result = $conn->query($sql);
      if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                  $Name=$row["EmpName"];
                  $Dept=$row["Dept"];
                  }
                }
               
                foreach($_POST as $key => $element) {  
                  // echo $key . ": " . $element . "<br>";  
              }
              // echo isset($_POST['loadSubmit']);

// if(isset($_POST['submit'])) 
// { // Fetching variables of the form which travels in URL
  // echo " HI there inside";

$Ltype = $_POST['type'];
$Lfrom = $_POST['from'];

$Lto = $_POST['to'];
$Ldays = $_POST['days'];
$Lreason = $_POST['reason'];
//if($name !=''||$email !=''){
//Insert Query of SQL
// loadadjustment data
$name=$_POST['name'];
$adjustment=$_POST['adjustment'];
$date=$_POST['date'];
$ldt=$_POST['ldto'];
$contact=$_POST['contact'];
$message=$_POST['message'];




$sql = "INSERT INTO emp_leaves(EmpName, LeaveType, LeaveDays, Reason, StartDate, EndDate, Dept) values ('$Name', '$Ltype', '$Ldays','$Lreason','$Lfrom','$Lto','$Dept');  INSERT INTO  loadajustment(EmpName,adjustment,enterdate,entertodate,entercontact, entermessage) VALUES('$name','$adjustment','$date','$ldt', '$contact', '$message');";
// $sql1="INSERT INTO loadadjustment(entername,adjustment,enterdate,entertodate,entercontact, entermessage) VALUES('$name','$adjustment','$date','$ldt', '$contact', '$message')";
// echo $sql1;
if ($conn->multi_query($sql) === TRUE) {
  
  echo "1";
  
}
else{
echo "0";
}

}
else
{
    header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
    exit();
}
//mysql_close($connection); // Closing Connection with Server
?>