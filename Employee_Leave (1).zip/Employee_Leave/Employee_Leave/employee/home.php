<html>
<head>
<title>::Leave Management::</title>
<style>
body {
  overflow-y: scroll; /* Add the ability to scroll */
}

/* Hide scrollbar for Chrome, Safari and Opera */
body::-webkit-scrollbar {
    display: none;
}

/* Hide scrollbar for IE and Edge */
body {
    -ms-overflow-style: none;
}
</style>
<link rel='stylesheet' type='text/css' href='style2.css'>
<!------ Include the above in your HEAD tag ---------->
</head>
<body>
<?php 
session_start();
if(isset($_SESSION['empuser']))
{ 
   include 'clientnavi3.php';	
   include 'connect.php';
   //echo "<h2>Welcome, " . $_SESSION["user"] ."</h2>";
   if(isset($_GET['err']))
		{
            $message1 = htmlspecialchars($_GET['err']);
			echo "<script type='text/javascript'>alert('$message1');</script>";
			header( "refresh:1;url=home.php" );
    }
    // if(isset($_POST['upload']))
    // {
    //   $file=addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
    //   $query1="INSERT INTO employees(image) VALUES('$file')";
    //   $query_run=mysqli_query($conn,$query1);
    //   if($query_run){
    //     echo '<script type="text/javascript">alert("Image Profile Uploaded") </script>';
    //   }
    //   else{
    //     echo '<script type="text/javascript">alert("Image Profile Not Uploaded") </script>';
    //   }
    // }
    $user = $_SESSION['empuser'];
    $sql="SELECT * FROM employees WHERE  UserName = '".$user."'";
    $result = $conn->query($sql);
        if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $Username=$row["UserName"];
                    $Email=$row["EmpEmail"];
                    $Name=$row["EmpName"];
                    $Dept=$row["Dept"];
                    $Eleave=$row["EarnLeave"];
                    $Sleave=$row["SickLeave"];
                    $Cleave=$row["CasualLeave"];
                    $SpclLeave=$row["SpecialLeave"];
                    $OutLeave=$row["OutdoorLeave"];
                    $LWPLeave=$row["LeaveWithoutPay"];
                    $CompLeave=$row["CompensatoryLeave"];
                    $SummerV=$row["SummerVacation"];
                    $WinterV=$row["WinterVacation"];
                    $DOJ=$row["DateOfJoin"];
                    $DOB=$row["DateOfBirth"];
                    $Desg=$row["Designation"];
                    $Mobile=$row["Mobile"];
                    $Faculty=$row["Faculty"];
                    $EmpType=$row["EmpType"];
                    $Image=$row['image'];
                    }
        }
   echo "</table>";
}
else
{
    header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
    exit();
}
?>

<div class="container" style="padding-left:20px;padding-right:20px;padding-top:10px;padding-bottom:60px;">
	<div class="row">
        
       <div class="col-md-7 ">
<form action="" method="POST" enctype="multipart/form-data">
<div class="panel panel-default">
  <div class="panel-heading">  <h4 >My Profile</h4></div>
   <div class="panel-body">
       
    <div class="box box-info">
        
            <div class="box-body">
                     
            <div class="col-sm-6" >
            <h4 style="color:#00b1b1;">Welcome <?php echo $Name;?></h4></span>
            </div>
            <div class="col-sm-6">
            <h4 style="color:#00b1b1;">Profile Picture</h4></span> 
              
              <div class="col-sm-6">
                <img src="../image/<?php echo $Image; ?>" class="img-fluid" style="border-radius:50%;height:100px;width:100px;" alt="">
              </div>
              
            </div>
            <div class="clearfix"></div>
            <hr style="margin:5px 0 5px 0;">
    
              
<div class="col-sm-5 col-xs-6 tital " >Username:</div><div class="col-sm-7 col-xs-6 "><?php echo $Username;?></div>
     <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Email ID:</div><div class="col-sm-7"><?php echo $Email;?></div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Department:</div><div class="col-sm-7"><?php echo $Dept;?></div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Date Of Joining:</div><div class="col-sm-7"><?php echo $DOJ;?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Date Of Birth:</div><div class="col-sm-7"><?php echo $DOB;?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Designation:</div><div class="col-sm-7"><?php echo $Desg;?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >EmpType:</div><div class="col-sm-7"><?php echo $EmpType;?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Earn Leave:</div><div class="col-sm-7"> <?php echo $Eleave;?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Sick Leave:</div><div class="col-sm-7"> <?php echo $Sleave;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Casual Leave:</div><div class="col-sm-7"><?php echo $Cleave;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Special Leave:</div><div class="col-sm-7"><?php echo $SpclLeave;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Outdoor Leave:</div><div class="col-sm-7"><?php echo $OutLeave;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Leave Without Pay Leave:</div><div class="col-sm-7"><?php echo $LWPLeave;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Compensatory Leave:</div><div class="col-sm-7"><?php echo $CompLeave;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Summer Vacation:</div><div class="col-sm-7"><?php echo $SummerV;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Winter Vacation:</div><div class="col-sm-7"><?php echo $WinterV;?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       
            
    </div> 
    </div>
    </form>
</div>  
   </div>
</div>
</body>
</html>