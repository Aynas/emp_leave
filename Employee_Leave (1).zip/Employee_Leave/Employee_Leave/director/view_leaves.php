<?php
session_start();
?>
<title>::Leave Management::</title>
<div class = "textview">
<center>
<?php


include 'connect.php';
include 'clientnavi3.php';
$count = 0;
if(isset($_SESSION['directoruser']))
	{
	//$sql = "SELECT Username FROM director WHERE UserName = '".$_SESSION['directoruser']."'";
	//$result = $conn->query($sql);
	//if($result->num_rows > 0)
		//{
		//while($row = $result->fetch_assoc())
			//{
			//if($_SESSION['directoruser'] == $row['UserName'])
				//{
				
				$sql2 = "SELECT e.id,e.Dept,e.EmpName,el.EmpName,el.LeaveType,el.RequestDate,el.LeaveDays,el.StartDate,el.EndDate,el.Id,el.Dept,la.adjustment FROM hod e, hod_leaves el, loadajustment la WHERE e.Dept = el.Dept AND el.EmpName=la.EmpName AND el.Status = 'Requested' AND e.EmpName = el.EmpName";
				$result2 = $conn->query($sql2);
				if($result2->num_rows > 0)
					{
						echo "<div class='container'>";
						echo "<table class='table table-bordered' style='background-color: #ffffff;'>";
						echo "<tr>";
						echo "<th>Employee Name</th>";
						echo "<th>Leave Type</th>";
						echo "<th>Request Date</th>";
						echo "<th>Leave Days</th>";
						echo "<th>Starting Date</th>";
						echo "<th>Ending Date</th>";
						echo "<th>Load Adjusted With</th>";
						echo "<th>Action</th>";
						echo "</tr>";
						while ($row2 = $result2->fetch_assoc())
							{
							echo "<tr>";
							echo "<td>";
							echo $row2['EmpName'];
							echo "</td>";
							echo "<td>";
							echo $row2['LeaveType'];
							echo "</td>";
							echo "<td>";
							echo $row2['RequestDate'];
							echo "</td>";
							echo "<td>";
							echo $row2['LeaveDays'];
							echo "</td>";
							echo "<td>";
							echo $row2['StartDate'];
							echo "</td>";
							echo "<td>";
							echo $row2['EndDate'];
							echo "</td>";
							echo "<td>";
							echo $row2['adjustment'];
							echo "</td>";
							echo "<td><a href = 'acceptleave.php?id=".$row2['Id']."&empid=".$row2["id"]."'>Accept</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href = 'rejectleave.php?id=".$row2['Id']."&empid=".$row2["id"]."'>Reject</a></td>";
							echo "</tr>";
							$count++;
							}
						echo '<h1 style="color:#009688;text-shadow: 0px 0px 2px #000000;">';
						echo $count;
						echo ' Leave(s)</h1>';
					}
					else{
						echo '<h1 style="color:#009688;text-shadow: 0px 0px 2px #000000;">';
						echo '0 Leave(s)</h1>';
					}
				echo "</table>";
				}
			//else
			//	{
			//	header("location:../signin.php?err=".urlencode('Please login first to view this page !'));
			//	}
		//	}
	//	}
//	}
else
	{
	header('location:../signin.php?err='.urlencode('Please login first to view this page !'));
	}
?>
</div>
</center>