<html>
<head>
<title>::Leave Management::</title>
<link rel='stylesheet' type='text/css' href='style2.css'>
<!------ Include the above in your HEAD tag ---------->
</head>
<body>
<?php 
session_start();
if(isset($_SESSION['directoruser']))
{ 
   include 'clientnavi3.php';	
   include 'connect.php';
   if(isset($_GET['err']))
    {
        $message1 = htmlspecialchars($_GET['err']);
        echo "<script type='text/javascript'>alert('$message1');</script>";
        header( "refresh:1;url=home.php" );
    }
    $user = $_SESSION['directoruser'];
    $sql="SELECT * FROM director WHERE  UserName = '".$user."'";
    $result = $conn->query($sql);
        if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $Username=$row["UserName"];
                    $Email=$row["EmpEmail"];
                    $Name=$row["EmpName"];
                    
                    }
        }
}
else
{
    header('location:../signin.php?err='.urlencode('Please Login First For Accessing This Page !'));
    exit();
}
?>

<div class="container">
<h1 style="text-align:center;color:#009688;font-size:60px;text-shadow: 0px 0px 2px #000000;">Welcome <?php echo $Name;?></h1>
</div>
</body>
</html>