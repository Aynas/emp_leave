<html>
<head>
<title>::Leave Management::</title>
<style>
body{
background-image:url("bg.jpg");
height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
</head>
<body>
<?php include 'navi3.php';?>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
    <div class="container">

      <div class="row align-items-center text-center text-md-left">
        <div class="col-md-6 col-lg-5 mb-5 mb-md-0 thumbnail">
		<div class="caption">
          <h1>Welcome User!</h1>
          <h5>Please login to continue...</h5>
		  <!--a class="button btn btn-primary mt-4" href="admin/index.php">Admin</a-->
		  <a class="button btn btn-primary mt-4 btn-block" href="signin.php">Login</a>
        </div>
        </div>
      </div>
</div>
</body>
</html>