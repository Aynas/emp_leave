<!--link rel="shortcut icon" type="image/png" href="favicon.png"/-->
<?php
session_start();
if(isset($_SESSION['adminuser']))
	{
	header('location:home.php');
	}
		if(isset($_GET['err']))
		{
			//echo "<div class = 'error'><b><u>".htmlspecialchars($_GET['err'])."</u></b></div><br/>";
			$message1 = htmlspecialchars($_GET['err']);
			echo "<script type='text/javascript'>alert('$message1');</script>";
			header( "refresh:1;url=signin.php" );
		}
?>

<html>
<head>
<title>::Leave Management::</title>
<link rel="stylesheet" type="text/css" href="signin.css">
<!-- <script type = "text/javascript">
function valid()
{
	var user = document.login.uname.value;
	var user = user.trim();
	var pass = document.login.pass.value;
	if (user == '')
		{
			alert("Please Enter Username !");
			return false;
		}
	else if (pass == '')
		{
			alert("Please Enter Password !");
			return false;
		}
	else
		{
			return true;
		}
}
</script> -->

</head>
<?php
//This code runs if the form has been submitted
if (isset($_POST['submit']))
{
 
// check for valid email address
$email = $_POST['email'];
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
     $error[] = 'Please enter a valid email address';
}
 
// checks if the username is in use
$check = $mysqli->query("SELECT EmpEmail FROM employees WHERE EmpEmail = '$email'");
$check2 =$check->num_rows;
 
 
//if the name exists it gives an error
if ($check2 == 0) {
$error[] = 'Sorry, Your emails doesnt exists in our record';
}
 
 
if (!$error) {
 
$query = $mysqli->query("SELECT EmpName FROM employees WHERE EmpEmail = '$email' ");
$r=$mysqli->fetch_object($query);
 
//create a new random password
 
$password = substr(md5(uniqid(rand(),1)),3,10);
$pass = md5($password); //encrypted version for database entry
 
//send email
$to = "$email";
$subject = "Account Details Recovery";
$body = "Hi $r->, nn you or someone else have requested your account details. nn Here is your account information please keep this as you may need this at a later stage. nnYour username is $r->username nn your password is $password nn Your password has been reset please login and change your password to something more rememberable.nn Regards Site Admin";
$lheaders= "From: <contact@domain.com>rn";
$lheaders.= "Reply-To: noprely@domain.com";
mail($to, $subject, $body, $additionalheaders);
 
//update database
$sql = $mysqli->query("UPDATE employees SET EmpPass='$pass' WHERE EmpEmail = '$email'");
$rsent = true;
 
 
}// close errors
}// close if form sent
 
//show any errors
if (!empty($error))
{
        $i = 0;
        while ($i < count($error)){
        echo "<div class='error-msg'>".$error[$i]."</div>";
        $i ++;}
}// close if empty errors
 
 
if ($rsent == true){
    echo "<p>Just sent an email with your account details to $email</p>n";
    } else {
    echo "<p>Please enter your e-mail address. You will receive a new password via e-mail.</p>n";
    }
 
?>

<html>
<head>
<title>::Leave Management::</title>
<!--link rel="stylesheet" type="text/css" href="style.css"-->
<link rel="stylesheet" type="text/css" href="signin.css">
<!-- <script type = "text/javascript">
function valid()
{
	var user = document.login.uname.value;
	var user = user.trim();
	var pass = document.login.pass.value;
	if (user == '')
		{
			alert("Please Enter Username !");
			return false;
		}
	else if (pass == '')
		{
			alert("Please Enter Password !");
			return false;
		}
	else
		{
			return true;
		}
}
</script> -->

</head>

<body>
<?php include 'navi3.php';?>
<!--div class="card col-sm-4 col-lg-4 justify-content-center"-->
<form class="form-signin" name='login' action='validator.php' method = 'post' onsubmit = 'return valid()'>
  <!--img class="mb-4 rounded mx-auto d-block" src="default-image.png" alt="" width="72" height="72"-->
  <h1 class="h2 mb-2 font-weight-normal" style='text-shadow: 0px 0px 2px #000000;'>Forgot Password?</h1>
  <br>
  <!--label for="inputEmail" class="sr-only" >Email address</label-->
  <input type="email" id="inputEmail" class="form-control" placeholder="Enter your Email" name='Email' required autofocus>
  <!--label for="inputPassword" class="sr-only">Password</label-->
  <br>
  <input type="password" id="inputPassword" class="form-control" placeholder="Password" name='pass' required>

  <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit">Change Password</button>

  <h4><a class="mt-5 mb-3 text-muted" href = 'signin.php' style='text-shadow: 0px 0px 2px #000000;'>Login</a></h4>
</form>
</div>


</body>
</html>

